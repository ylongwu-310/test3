# -*- coding: utf-8 -*-
__author__ = u"蓝鲸智云"
__copyright__ = "Copyright © 2012-2017 Tencent BlueKing. All Rights Reserved."
